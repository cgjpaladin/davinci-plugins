"""
批量命名工具 · WebView 生产版
Python 后端 + HTML/CSS 前端
"""
import os, sys, json, re, shutil, statistics
from datetime import datetime
from urllib.parse import unquote

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from shared.naming import (
    FIELD_CONFIG, DISPLAY_FIELDS, METHOD_DESC_MAP, FIELD_RULES,
    build_filename, parse_filename, build_folder,
    MEDIA_EXT, sanitize_text,
)
from shared.naming_checks import check_zero_byte, check_double_ext, check_size_anomaly

import webview
import logging, tempfile
_log = logging.getLogger("renamer_web")
_log.setLevel(logging.DEBUG)
try:
    _hdlr = logging.FileHandler(os.path.join(tempfile.gettempdir(), "renamer_web.log"))
    _hdlr.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
    _log.addHandler(_hdlr)
except Exception:
    pass  # 日志文件不可用时静默跳过

# pyinstaller 打包后 sys._MEIPASS = app bundle 资源目录
_BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
_SHARED_DIR = os.path.join(_BASE_DIR, 'shared')
if os.path.isdir(_SHARED_DIR) and _SHARED_DIR not in sys.path:
    sys.path.insert(0, os.path.dirname(_SHARED_DIR))

# 视频扩展名集合 + 文件对话框过滤器
VIDEO_EXT = {'.mp4','.mov','.mxf','.avi','.mkv','.webm','.m4v','.mts','.mpg','.mpeg','.wmv','.3gp','.flv','.r3d','.braw'}
_DIALOG_FILTER = "媒体文件 (" + ";".join(sorted(e.replace(".","*.") for e in VIDEO_EXT)) + ")"

CFG_FILE = os.path.join(os.path.expanduser("~"), ".renamer_saved.json")
PATH_RE = re.compile(r"^(\d{8})_(.+)$")

_saved_defaults = {}
if os.path.exists(CFG_FILE):
    try:
        with open(CFG_FILE, "r", encoding="utf-8") as f:
            _saved_defaults = json.load(f)
    except Exception:
        pass

THUMB_MAX = 100  # 缩略图批次上限
_undo_stack = []  # list of lists: [[(old,new),...], [(old,new),...]]
_window = None  # 存引用


class RenamerAPI:
    def pick_dest_folder(self):
        """打开文件夹选择框，返回路径"""
        result = _window.create_file_dialog(webview.FOLDER_DIALOG)
        if result and len(result) > 0:
            return {"path": result[0]}
        return {"path": ""}

    def generate_thumbnails(self, paths):
        """用 ffmpeg 提取视频第一帧，逐帧推送到 JS（渐进渲染）"""
        import subprocess, base64, tempfile, shutil, sys, json
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            for pfx in (sys._MEIPASS if getattr(sys,'_MEIPASS',False) else '', '/opt/homebrew/bin', '/usr/local/bin'):
                exe_name = 'ffmpeg.exe' if sys.platform == 'win32' else 'ffmpeg'
                test = os.path.join(pfx, exe_name) if pfx else 'ffmpeg'
                if os.path.exists(test): ffmpeg = test; break
        if not ffmpeg: ffmpeg = 'ffmpeg'
        _log.info(f"generate_thumbnails: {len(paths)} files, ffmpeg={ffmpeg}")
        total = 0
        for p in paths[:THUMB_MAX]:
            try:
                tmp = tempfile.NamedTemporaryFile(suffix='.jpg', delete=False)
                tmp.close()
                kw = dict(capture_output=True, timeout=8)
                if sys.platform == 'win32':
                    kw['creationflags'] = subprocess.CREATE_NO_WINDOW
                # 先尝试 1 秒处抽帧；失败则用首帧（视频短于 1 秒）
                for ss in ('00:00:01', '00:00:00.1'):
                    subprocess.run(
                        [ffmpeg, '-y', '-ss', ss, '-i', p, '-vframes', '1',
                         '-vf', 'scale=120:120:force_original_aspect_ratio=decrease',
                         '-q:v', '8', tmp.name],
                        **kw
                    )
                    if os.path.isfile(tmp.name) and os.path.getsize(tmp.name) > 100:
                        break
                if os.path.isfile(tmp.name) and os.path.getsize(tmp.name) > 100:
                    with open(tmp.name, 'rb') as f:
                        b64 = base64.b64encode(f.read()).decode()
                    thumb = f"data:image/jpeg;base64,{b64}"
                    if _window:
                        _window.evaluate_js(f"setThumb({json.dumps(p)},{json.dumps(thumb)})")
                    total += 1
                try: os.unlink(tmp.name)
                except OSError: pass
            except Exception as e:
                _log.info(f"  thumb error: {e}")
                try: os.unlink(tmp.name)
                except OSError: pass
        _log.info(f"generate_thumbnails done: {total} thumbs")
        return {"thumbs": {}, "total": total}

    def get_config(self):
        fmt = []
        for fd in FIELD_CONFIG:
            nm = fd["name"]; k = fd["key"]
            if nm == "Ep": fmt.append({"pfx":"Ep","key":"ep"})
            elif nm == "Sc": fmt.append({"pfx":"Sc","key":"sc"})
            elif nm == "Gr": fmt.append({"pfx":"Gr","key":"gr"})
            elif nm == "Tk": fmt.append({"pfx":"Tk","key":"tk"})
            elif nm == "v": fmt.append({"pfx":"v","key":"ver"})
            elif k == "status": fmt.append({"pfx":"","key":"status"})
            else: fmt.append({"pfx":"","key":k})
        is_dev = not getattr(sys, '_MEIPASS', False)
        return {
            "fields": FIELD_CONFIG,  # 含 tk，P1a 动态 inspector 需要
            "dev": is_dev,
            "defaults": _saved_defaults,
            "method_desc_map": METHOD_DESC_MAP,
            "field_rules": FIELD_RULES,
            "name_format": fmt,
        }

    def add_files_via_dialog(self):
        result = _window.create_file_dialog(
            webview.OPEN_DIALOG, allow_multiple=True,
            file_types=(_DIALOG_FILTER,),
        )
        if not result:
            return {"files": [], "total": 0}
        paths = result if isinstance(result, list) else [result]
        return self._process_paths(paths)

    def add_folder_via_dialog(self):
        result = _window.create_file_dialog(webview.FOLDER_DIALOG)
        if not result or len(result) == 0:
            return {"files": [], "total": 0}
        folder = result[0]
        paths = []
        try:
            for f in sorted(os.listdir(folder)):
                fp = os.path.join(folder, f)
                if os.path.isfile(fp):
                    paths.append(os.path.realpath(fp))
        except Exception:
            pass
        return self._process_paths(paths)

    def add_files_by_paths(self, paths):
        _log.info(f"add_files_by_paths paths={[str(p)[:80] for p in (paths or [])[:5]]}")
        return self._process_paths(paths)

    _dbg_buf = []  # 内存调试日志（最后 500 条）

    def debug_log(self, msg):
        if msg:
            self._dbg_buf.append(msg)
            if len(self._dbg_buf) > 500:
                self._dbg_buf = self._dbg_buf[-500:]
            _log.info(f"[JS] {msg}")
            return "ok"
        return {"log": list(self._dbg_buf)}

    def _process_paths(self, paths_):
        _log.info(f"_process_paths: {len(paths_)} paths → scanning")
        MAX_FILES = 100
        files = []; duplicates = 0; skipped = 0; subdirs = 0; truncated = False
        seen_fp = set()  # 本批指纹，不跨批
        _EMPTY_KEYS = {fd["key"] for fd in FIELD_CONFIG if fd.get("name")}  # 有前缀的字段不继承解析值
        parsed_count = 0; no_parse_count = 0
        for p_ in paths_[:MAX_FILES]:
            if len(files) >= MAX_FILES: truncated = True; break
            p = str(p_).strip()
            if p.startswith("file://"): p = unquote(p[7:])

            if os.path.isfile(p):
                ext = os.path.splitext(p)[1].lower()
                if ext not in VIDEO_EXT:
                    _log.debug(f"  skip non-video: {os.path.basename(p)}")
                    skipped += 1
                    continue
                if p in {f["path"] for f in files}: duplicates += 1; continue
                # 内容指纹：size + 前 64KB hash（同一文件走不同路径也能去重）
                try:
                    import hashlib
                    st = os.stat(p)
                    fp_key = f"{st.st_size}:{hashlib.md5(open(p,'rb').read(65536)).hexdigest()}"
                except OSError:
                    fp_key = p  # fallback to path
                if fp_key in seen_fp: duplicates += 1; continue
                seen_fp.add(fp_key)
                parsed = parse_filename(p)
                fields = {}
                for fd in FIELD_CONFIG:
                    k = fd["key"]
                    if parsed and k in parsed: fields[k] = parsed[k]
                    elif k in _EMPTY_KEYS: fields[k] = ""
                    else: fields[k] = fd["def"]
                if parsed: parsed_count += 1
                else: no_parse_count += 1
                _log.debug(f"  + {os.path.basename(p)} parsed={bool(parsed)} ep={fields.get('ep','')} sc={fields.get('sc','')} gr={fields.get('gr','')} desc={fields.get('desc','')}|method={fields.get('method','')}|author={fields.get('author','')}|v{fields.get('ver','')}|{fields.get('status','')}")
                files.append({"path":p,"basename":os.path.basename(p),"ext":os.path.splitext(os.path.basename(p))[1],"fields":fields,"fp":fp_key})
            elif os.path.isdir(p):
                try:
                    for f in sorted(os.listdir(p)):
                        fp = os.path.join(p, f)
                        if os.path.isfile(fp):
                            ext2 = os.path.splitext(fp)[1].lower()
                            if ext2 not in VIDEO_EXT: continue
                            if fp in {x["path"] for x in files}: duplicates += 1; continue
                            try:
                                st = os.stat(fp)
                                fp_key2 = f"{st.st_size}:{hashlib.md5(open(fp,'rb').read(65536)).hexdigest()}"
                            except OSError:
                                fp_key2 = fp
                            if fp_key2 in {x.get("fp","") for x in files}: duplicates += 1; continue
                            if len(files) >= MAX_FILES: truncated = True; break
                            parsed = parse_filename(fp)
                            fields = {}
                            for fd in FIELD_CONFIG:
                                k = fd["key"]
                                if parsed and k in parsed: fields[k] = parsed[k]
                                elif k in _EMPTY_KEYS: fields[k] = ""
                                else: fields[k] = fd["def"]
                            if parsed: parsed_count += 1
                            else: no_parse_count += 1
                            _log.debug(f"  + {os.path.basename(fp)} parsed={bool(parsed)} ep={fields.get('ep','')} sc={fields.get('sc','')}")
                            files.append({"path":fp,"basename":os.path.basename(fp),"ext":os.path.splitext(os.path.basename(fp))[1],"fields":fields,"fp":fp_key2})
                        elif os.path.isdir(fp): subdirs += 1
                except Exception: pass

        _log.info(f"_process_paths: {len(files)} files, {parsed_count} parsed, {no_parse_count} raw, {duplicates} dup, {skipped} skipped, {subdirs} subdirs, truncated={truncated}")
        files.sort(key=lambda f: f["basename"])
        # 自动检查
        anomalies = set()
        try:
            sp = [(fp, os.path.getsize(fp)) for f in files for fp in [f["path"]] if os.path.getsize(fp) > 0]
            vals = [s for _,s in sp]
            if len(vals) >= 3:
                mu = statistics.mean(vals); sd = statistics.stdev(vals)
                cv = sd/mu if mu > 0 else 0
                _log.info(f"auto-check: {len(vals)} files, mean={mu/1024/1024:.1f}MB sd={sd/1024/1024:.1f}MB cv={cv:.2f}")
                if cv > 1.0:
                    anomalies = {fp for fp,_ in sp if abs(os.path.getsize(fp)-mu) > 2*sd}
                    _log.info(f"  anomalies: {len(anomalies)}")
        except Exception as e:
            _log.info(f"  auto-check error: {e}")
        for f in files:
            tags = []
            if check_zero_byte(f["path"]): tags.append("zero")
            if check_double_ext(f["basename"]): tags.append("dbl_ext")
            if f["path"] in anomalies: tags.append("size")
            f["tags"] = tags
        return {"files":files,"total":len(files),"duplicates":duplicates,"skipped":skipped,"subdirs_skipped":subdirs,"truncated":truncated,"max":MAX_FILES}

    def do_rename(self, files):
        global _undo_stack
        ok = 0; fail = []; batch = []; renamed = []
        _log.info(f"do_rename: {len(files)} files")
        for f in files:
            p = f["path"]
            d = os.path.dirname(p)
            ext = os.path.splitext(os.path.basename(p))[1]
            nm = build_filename(f["fields"]) + ext
            np = os.path.join(d, nm)
            if os.path.exists(np) and os.path.normcase(np) != os.path.normcase(p):
                fail.append(os.path.basename(p) + " → 已存在")
                _log.warning(f"  rename collision: {os.path.basename(p)} → {os.path.basename(np)}")
                continue
            try:
                os.rename(p, np)
                batch.append((p, np))
                renamed.append({"old_path": p, "new_path": np})
                _log.debug(f"  ✓ {os.path.basename(p)} → {os.path.basename(np)}")
                ok += 1
            except Exception as e:
                fail.append(os.path.basename(p) + ": " + str(e))
        if files:
            sv = {k: v for k, v in files[0]["fields"].items() if k != "tk"}
            try:
                with open(CFG_FILE, "w", encoding="utf-8") as fp:
                    json.dump(sv, fp, ensure_ascii=False, indent=2)
                global _saved_defaults
                _saved_defaults = sv
            except Exception:
                pass
        if batch:
            _undo_stack.append({"type": "rename", "pairs": [(op, np) for op, np in batch]})
        _log.info(f"do_rename: {ok} ok, batch={len(batch)}, stack_depth={len(_undo_stack)}")
        return {"ok": ok, "fail": fail, "total": len(files), "renamed": renamed, "stack_depth": len(_undo_stack)}

    def do_undo(self):
        global _undo_stack
        if not _undo_stack:
            return {"ok": 0, "msg": "没有可撤销的操作"}
        entry = _undo_stack.pop()
        # 兼容旧格式: list of tuples
        if isinstance(entry, list):
            entry = {"type": "rename", "pairs": entry}
        typ = entry.get("type", "rename")
        pairs = entry.get("pairs", [])
        ud = 0; renamed = []
        for op, np in pairs:
            try:
                if typ == "archive":
                    os.remove(np)  # 删除已归档的文件
                    renamed.append({"old_path": np, "new_path": op})  # 通知 JS 还原文件引用
                else:
                    os.rename(np, op)
                    renamed.append({"old_path": np, "new_path": op})
                ud += 1
            except Exception:
                pass
        _log.info(f"do_undo: {ud}/{len(pairs)} {typ} reversed, remaining batches: {len(_undo_stack)}")
        return {"ok": ud, "msg": f"已撤销 {ud} 个", "remaining": len(_undo_stack), "renamed": renamed, "type": typ}

    def validate_dest(self, dest):
        v = str(dest).strip()
        if not v: return {"ok": False, "msg": ""}
        # smb:// → /Volumes/ 静默转换
        v = re.sub(r'^smb://[\d.]+/', '/Volumes/', v)
        m = PATH_RE.match(os.path.basename(v))
        if not m: return {"ok": False, "msg": "✗ 格式: YYYYMMDD_项目名"}
        try: datetime.strptime(m.group(1), "%Y%m%d")
        except ValueError: return {"ok": False, "msg": "✗ 无效日期"}
        name = m.group(2)
        cleaned, warns = sanitize_text(name, for_filename=True)
        if not cleaned: return {"ok": False, "msg": "✗ 项目名不能为空"}
        if warns: return {"ok": False, "msg": "✗ " + "; ".join(warns)}
        if len(cleaned) > 50: return {"ok": False, "msg": "✗ 项目名过长 (≤50字)"}
        return {"ok": True, "msg": "✓ 格式正确"}

    def do_archive(self, files, dest):
        import hashlib
        _log.info(f"do_archive: {len(files)} files, dest={dest}")
        ok = 0; fail = []; dup = 0; dest = os.path.realpath(re.sub(r'^smb://[\d.]+/', '/Volumes/', str(dest).strip()))
        def _hash_file(p):
            h = hashlib.sha256()
            with open(p, 'rb') as fh:
                while True:
                    chunk = fh.read(65536)
                    if not chunk: break
                    h.update(chunk)
            return h.digest()
        # 扫目标文件夹，预建 {hash: path}（同内容只保留一条，限 200 个文件）
        seen = {}  # hash bytes → path
        if os.path.isdir(dest):
            for root, dirs, filenames in os.walk(dest):
                for fn in filenames:
                    if len(seen) >= 200: break
                    fp = os.path.join(root, fn)
                    try:
                        sz = os.path.getsize(fp)
                        if sz > 0:
                            h = _hash_file(fp)
                            if h not in seen: seen[h] = fp
                    except OSError: pass
        # 逐文件处理
        archived = []
        for f in files:
            fd = f.get("fields", {})
            ext = f.get("ext", ".mp4")
            # 构建目标文件夹
            target = build_folder(dest, type('E',(),{'fields':fd,'ext':ext})())
            folder = os.path.dirname(target)
            os.makedirs(folder, exist_ok=True)
            # 扫描文件夹找最大 TK（同 Ep/Sc/Gr/desc/method/author/ver/status 归一组）
            try:
                max_tk = 0
                if os.path.isdir(folder):
                    # 用 tk='00' 构建模板，split 精准切分前缀
                    fd_copy = dict(fd); fd_copy['tk'] = '00'
                    sample = build_filename(fd_copy)
                    parts = sample.split('_Tk00_', 1)
                    if len(parts) == 2:
                        tk_prefix = parts[0] + '_Tk'
                        for fn in os.listdir(folder):
                            if not fn.startswith(tk_prefix): continue
                            m = re.search(r'\bTk(0[1-9]|[1-9]\d)(?:_|\.mp4|\.mov|\.mxf|\.avi|\.mkv|$)', fn)
                            if m:
                                max_tk = max(max_tk, int(m.group(1)))
                nxt = max_tk + 1
                if nxt > 99: fail.append(f'{fd.get("ep","?")}_{fd.get("sc","?")}: TK 已满(99)'); continue
                fd['tk'] = str(nxt).zfill(2)
                target = os.path.join(folder, build_filename(fd) + ext)
            except Exception:
                fd['tk'] = '01'
                target = build_folder(dest, type('E',(),{'fields':fd,'ext':ext})())
            # 目标路径碰撞检测（同字段不同内容 → 会覆盖，不应发生）
            try:
                if os.path.exists(target):
                    # 尝试找下一个可用 TK
                    orig_tk = fd.get('tk', '01')
                    for n in range(int(orig_tk)+1, 100):
                        fd['tk'] = str(n).zfill(2)
                        alt = os.path.join(folder, build_filename(fd) + ext)
                        if not os.path.exists(alt):
                            target = alt; break
                    else:
                        fail.append(f'{os.path.basename(target)}: TK 已满(99)'); continue
                # 哈希去重
                src_hash = _hash_file(f["path"])
                if src_hash in seen: dup += 1; continue
                shutil.copy2(f["path"], target)
                seen[src_hash] = target
                archived.append((f["path"], target))
                ok += 1
                _log.debug(f"  ✓ {os.path.basename(f['path'])} → {os.path.basename(target)}")
            except Exception as e:
                fail.append(os.path.basename(f["path"]) + ": " + str(e))
                _log.warning(f"  ✗ {os.path.basename(f['path'])}: {e}")
        if archived:
            _undo_stack.append({"type": "archive", "pairs": archived})
        return {"ok": ok, "dup": dup, "fail": fail, "total": len(files), "archived": [{"old": src, "new": dst} for src, dst in archived], "stack_depth": len(_undo_stack)}

    def export_table(self, rows):
        """生成 xlsx 文件（openpyxl，含嵌入缩略图），返回 base64"""
        import base64 as _b64, io, re as _re
        from openpyxl import Workbook
        from openpyxl.drawing.image import Image as XLImage
        from openpyxl.utils import get_column_letter
        from PIL import Image as PILImage

        # ── 列定义（单一事实来源，不再并行维护 HEADERS/KEYS/WIDTHS/NUM_KEYS）──
        COLUMNS = [
            {"header":"缩略图",  "key":"thumb",    "width":12, "zfill":False},
            {"header":"集数",    "key":"ep",       "width":5,  "zfill":True},
            {"header":"场次",    "key":"sc",       "width":5,  "zfill":True},
            {"header":"小场次",  "key":"gr",       "width":5,  "zfill":True},
            {"header":"次数",    "key":"tk",       "width":5,  "zfill":True},
            {"header":"描述",    "key":"desc",     "width":15, "zfill":False},
            {"header":"制作方式", "key":"method",   "width":10, "zfill":False},
            {"header":"制作者",   "key":"author",   "width":10, "zfill":False},
            {"header":"版本",    "key":"ver",      "width":5,  "zfill":True},
            {"header":"通过情况", "key":"status",   "width":6,  "zfill":False},
            {"header":"文件名",   "key":"_newname", "width":45, "zfill":False},
        ]

        # ── 从 FIELD_CONFIG 推导（不手写第二份）──
        _PFX = {fd["key"]: fd["name"] for fd in FIELD_CONFIG if fd.get("name")}
        _FIELDS = [fd["key"] for fd in FIELD_CONFIG]

        # ── 布局常量 ──
        THUMB_W, THUMB_H_MAX = 72, 60
        DEFAULT_ROW_H = 15

        wb = Workbook()
        ws = wb.active
        ws.title = "文件列表"

        # 表头 + 列宽 + 冻结首行
        for ci, col in enumerate(COLUMNS):
            ws.cell(row=1, column=ci+1, value=col["header"])
            ws.column_dimensions[get_column_letter(ci+1)].width = col["width"]
        ws.freeze_panes = 'A2'

        # 数据行
        for rn, row in enumerate(rows):
            row_h = DEFAULT_ROW_H
            for ci, col in enumerate(COLUMNS):
                k = col["key"]
                if k == 'thumb':
                    thumb = row.get('thumb', '')
                    if thumb and thumb.startswith('data:image/'):
                        m = _re.match(r'data:image/(\w+);base64,(.+)', thumb)
                        if m:
                            data = _b64.b64decode(m.group(2))
                            try:
                                pil = PILImage.open(io.BytesIO(data))
                                pw, ph = pil.size
                                ratio = pw / ph if ph else 1
                                img = XLImage(io.BytesIO(data))
                                if ratio >= 1:
                                    img.width = THUMB_W
                                    img.height = max(1, int(THUMB_W / ratio))
                                else:
                                    img.height = THUMB_H_MAX
                                    img.width = max(1, int(THUMB_H_MAX * ratio))
                                import openpyxl.utils.units as oxu
                                row_pt = oxu.pixels_to_points(img.height) + 4
                                row_h = max(row_h, row_pt)
                            except Exception:
                                img = XLImage(io.BytesIO(data))
                                img.width = 60; img.height = 45
                                row_h = max(row_h, 50)
                            img.anchor = f'{get_column_letter(ci+1)}{rn+2}'
                            ws.add_image(img)
                elif k == '_newname':
                    parts = []
                    for fk in _FIELDS:
                        fv = str(row.get(fk, ''))
                        if fv:
                            pfx = _PFX.get(fk, '')
                            parts.append(f'{pfx}{fv}' if pfx else fv)
                    name = '_'.join(parts)
                    ws.cell(row=rn+2, column=ci+1, value=name + str(row.get('ext', '')))
                else:
                    val = str(row.get(k, ''))
                    if col.get("zfill") and val:
                        ws.cell(row=rn+2, column=ci+1, value=val.zfill(2))
                    else:
                        ws.cell(row=rn+2, column=ci+1, value=val)
            ws.row_dimensions[rn+2].height = row_h

        buf = io.BytesIO()
        wb.save(buf)
        return {'data': _b64.b64encode(buf.getvalue()).decode('ascii'), 'type': 'xlsx'}

    def save_file(self, data, default_name):
        """打开原生保存对话框，写入文件。返回 {ok: true/false, path: '...'}"""
        import base64 as _b64
        result = _window.create_file_dialog(
            webview.SAVE_DIALOG, save_filename=default_name,
            file_types=("Excel 文件 (*.xlsx)",),
        )
        if not result:
            return {"ok": False, "path": ""}
        try:
            with open(result, "wb") as f:
                f.write(_b64.b64decode(data))
            return {"ok": True, "path": result}
        except Exception as e:
            _log.warning(f"save_file failed: {e}")
            return {"ok": False, "path": result}


# 自动检测打包后的 HTML 文件（支持卡片版/表格版）
_HTML_CANDIDATES = ["renamer_web.html", "renamer_table.html"]
HTML_FILE_NAME = "renamer_web.html"  # 默认
for _c in _HTML_CANDIDATES:
    if os.path.isfile(os.path.join(_BASE_DIR, _c)):
        HTML_FILE_NAME = _c; break
HTML_FILE = os.path.join(_BASE_DIR, HTML_FILE_NAME)

if __name__ == "__main__":
    import threading, socket
    from bottle import route, run, static_file

    # 用 bottle HTTP 服务绕过 WKWebView 沙箱限制
    @route('/')
    def index():
        return static_file(HTML_FILE_NAME, root=_BASE_DIR)

    # 找空闲端口
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(('127.0.0.1', 0))
    port = sock.getsockname()[1]
    sock.close()

    # 后台启动 bottle
    t = threading.Thread(target=lambda: run(host='127.0.0.1', port=port, quiet=True), daemon=True)
    t.start()

    # 等 bottle 就绪
    import time, urllib.request
    for _ in range(20):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}", timeout=0.5)
            break
        except Exception:
            time.sleep(0.1)

    api = RenamerAPI()
    _window = webview.create_window(
        title="批量文件命名工具",
        url=f"http://127.0.0.1:{port}",
        js_api=api,
        width=880, height=620,
        min_size=(680, 400),
        resizable=True,
        background_color='#151515',
        text_select=True,
    )

    # 拖放：用 loaded 事件在 DOM 就绪后绑定 Python 端 handler
    def _bind_drop():
        from webview.dom import DOMEventHandler
        def _on_drop(e):
            files = e['dataTransfer']['files']
            paths = []
            for f in files:
                fp = f.get('pywebviewFullPath', '')
                if not fp: continue
                if os.path.isfile(fp):
                    paths.append(os.path.realpath(fp))
                elif os.path.isdir(fp):
                    try:
                        for sf in sorted(os.listdir(fp)):
                            sfp = os.path.realpath(os.path.join(fp, sf))
                            if os.path.isfile(sfp):
                                paths.append(sfp)
                    except Exception: pass
            if not paths: return
            _log.info(f"DOM drop: {len(paths)} items [{', '.join(os.path.basename(p) for p in paths[:5])}{'...' if len(paths)>5 else ''}]")
            result = api._process_paths(paths)
            duplicates = result.get('duplicates', 0)
            if duplicates and not result.get('files'):
                _window.evaluate_js(f'toast("全部重复 · {duplicates} 个已跳过")')
            else:
                _window.evaluate_js(f"onDropResult({json.dumps(result)})")

        _window.dom.document.events.dragover += DOMEventHandler(lambda e: e, prevent_default=True)
        _window.dom.document.events.drop += DOMEventHandler(_on_drop, prevent_default=True, stop_propagation=True)
        _log.info("DOM drop handler bound")

    _window.events.loaded += _bind_drop

    webview.start(debug=False)
