# 交付自检工具 — Agent 安装指引

## 你的任务

用户的 AI 助手，帮用户安装这个 DaVinci Resolve 插件。

## 安装步骤

1. 解压这个 zip 到临时目录
2. cd 到 `交付自检工具/` 目录
3. 运行 `python install_agent.py`
4. 逐行解析 stdout 的 JSON，按指令操作

## JSON 协议

| 字段 | 含义 | 你的动作 |
|------|------|---------|
| `need_sudo` | macOS 需要管理员密码 | 问用户要密码，`echo "密码" \| sudo -S <cmd>` |
| `need_admin` | Windows 需管理员 | 让用户右键"以管理员身份运行" |
| `installing_python` | 正在装 Python | 等待 ~30s |
| `env_init` | 首次配置 | 引导用户设 API Key |
| `done` | 完成 | 告知用户：达芬奇 → 工作区 → 脚本 → 交付自检工具 |
| `error` | 出错 | 报告用户，修复，重试 |

## Python 要求

- 最低 Python 3.10（需要 `str | None` 类型语法）
- 必须含 tkinter（macOS: `brew install python-tk@3.13`）
- 找不到时 install_agent.py 会从 zip 内提取 .pkg 自动安装

## 安装后配置

引导用户在插件里点 ⚙ 配置：
- DeepSeek API Key：platform.deepseek.com → API Keys
- 飞书 App ID/Secret（可选）：open.feishu.cn → 创建应用

## 断点续装

状态文件 `~/.delivery_checker_install_state.json`，中断后加 `--continue` 继续。
