"""部署配置统一入口。

取代各产品目录中分散复制的 _load_deploy_config() / _read_smb_mount()。
单一来源：~/达芬奇插件工坊/deploy.json
"""
import json as _json
import os as _os


def load() -> dict:
    """读取 deploy.json，不存在返回空 dict。"""
    cfg_path = _os.path.expanduser("~/达芬奇插件工坊/deploy.json")
    try:
        with open(cfg_path, encoding="utf-8") as f:
            return _json.load(f)
    except Exception:
        return {}


def get_smb_mount(default="/Volumes/MYJC") -> str:
    """读取 SMB 挂载点。"""
    cfg = load()
    return cfg.get("smb_mount", default) or default


def get_python_path() -> str:
    """自动发现外挂 Python 路径（用于 subprocess 启动 UI）。
    
    跳过达芬奇自带的 Python。优先取最新框架安装版。
    装好 Python 即可，无需 JSON 配置。
    """
    import glob as _glob

    candidates = []
    # 官版安装器：自动匹配 3.10~3.99，排序取最新
    candidates.extend(sorted(_glob.glob(
        "/Library/Frameworks/Python.framework/Versions/3.*/bin/python3"
    ), reverse=True))
    # Homebrew (Apple Silicon / Intel)
    candidates.extend(sorted(_glob.glob("/opt/homebrew/bin/python3*"), reverse=True))
    candidates.extend(sorted(_glob.glob("/usr/local/bin/python3*"), reverse=True))
    # 最后兜底
    candidates.append("/usr/bin/python3")

    for p in candidates:
        if not _os.path.exists(p):
            continue
        try:
            real = _os.path.realpath(p)
        except Exception:
            real = p
        if "/DaVinci Resolve/" in real:
            continue  # 跳过达芬奇自带的
        return p

    return "/usr/bin/python3"
